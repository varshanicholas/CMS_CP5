﻿using CMS.Models;

namespace CMS.Repository
{
    public interface IReceptionistRepository
    {
        public IEnumerable<Patients> GetPatients();

        public void AddPatients(Patients pat);

        public Patients GetPatientById(int? Id);


        public void UpdatePatients(Patients pat);

       // void AddAppointments(AppointmentModel app);
       
        public void AddAppointments(AppointmentModel app);
        public IEnumerable<Doctor> GetDoctorsByDepartment(int departmentId);
        public IEnumerable<Department> GetDepartments();
        //IEnumerable<Doctor> GetDoctors();
        //IEnumerable<AppointmentModel> GetAppointmentsByPatientId(int patientId);


    }
}
