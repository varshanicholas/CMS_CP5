﻿using CMS.Models;
using System.Data.SqlClient;
using System.Data;
using Microsoft.AspNetCore.Mvc;


namespace CMS.Repository
{
    public class ReceptionistRepository : IReceptionistRepository
    {
        private readonly string connectionString;


        public ReceptionistRepository(IConfiguration configuration)
        {
            connectionString = configuration.GetConnectionString("connectionStringReceptionist");
        }

        public IEnumerable<Patients> GetPatients()
        {
            List<Patients> patList = new List<Patients>();

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                SqlCommand cmd = new SqlCommand("Sp_GetPatient", connection);
                cmd.CommandType = CommandType.StoredProcedure;
                connection.Open();
                SqlDataReader dr = cmd.ExecuteReader();
                while (dr.Read())
                {
                    Patients pat = new Patients();
                    pat.PatientId = Convert.ToInt32(dr["PatientId"]); // Maps to PatientId in the table
                    pat.PatientName = dr["PatientName"].ToString();  // Maps to PatientName in the table
                    pat.DOB = Convert.ToDateTime(dr["DOB"]);         // Maps to DOB in the table
                    pat.Gender = dr["Gender"].ToString();            // Maps to Gender in the table
                    pat.BloodGroup = dr["BloodGroup"].ToString();    // Maps to BloodGroup in the table
                    pat.PhoneNumber = dr["PhoneNumber"].ToString();  // Maps to PhoneNumber in the table
                    pat.Address = dr["Address"].ToString();          // Maps to Address in the table
                    pat.Email = dr["Email"] == DBNull.Value ? null : dr["Email"].ToString(); // Handles nullable Email field
                    pat.DateOfRegistration = Convert.ToDateTime(dr["DateOfRegistration"]);
                    patList.Add(pat);

                }
            }

            return patList;
        }

        public void AddPatients(Patients pat)
        {
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                SqlCommand cmd = new SqlCommand("sp_AddPatientR", connection); // Assuming procedure is named Sp_InsertPatient
                cmd.CommandType = CommandType.StoredProcedure;

                // Updated parameters to match the table structure
                cmd.Parameters.AddWithValue("@PatientName", pat.PatientName);
                cmd.Parameters.AddWithValue("@DOB", pat.DOB);
                cmd.Parameters.AddWithValue("@Gender", pat.Gender);
                cmd.Parameters.AddWithValue("@BloodGroup", pat.BloodGroup);
                cmd.Parameters.AddWithValue("@PhoneNumber", pat.PhoneNumber);
                cmd.Parameters.AddWithValue("@Address", pat.Address);
                cmd.Parameters.AddWithValue("@Email", pat.Email ?? (object)DBNull.Value); // Handle nullable Email
                cmd.Parameters.AddWithValue("@DateOfRegistration", pat.DateOfRegistration);
                connection.Open();
                cmd.ExecuteNonQuery();
            }
        }

        public Patients GetPatientById(int? Id)
        {
            Patients pat = new Patients();
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                SqlCommand cmd = new SqlCommand("Sp_PatientById", connection);
                cmd.CommandType = CommandType.StoredProcedure;

                cmd.Parameters.AddWithValue("@PatientId", Id);
                connection.Open();
                SqlDataReader dr = cmd.ExecuteReader();
                while (dr.Read())
                {
                    pat.PatientId = Convert.ToInt32(dr["PatientId"]);
                    pat.PatientName = dr["PatientName"].ToString();
                    pat.DOB = Convert.ToDateTime(dr["DOB"]);
                    pat.Gender = dr["Gender"].ToString();
                    pat.BloodGroup = dr["BloodGroup"].ToString();
                    pat.PhoneNumber = dr["PhoneNumber"].ToString();
                    pat.Address = dr["Address"].ToString();
                    pat.Email = dr["Email"] == DBNull.Value ? null : dr["Email"].ToString();
                    pat.DateOfRegistration = Convert.ToDateTime(dr["DateOfRegistration"]);
                }
            }
            return pat;
        }

        public void UpdatePatients(Patients pat)
        {
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                SqlCommand cmd = new SqlCommand("Sp_UpdatePatient", connection);
                cmd.CommandType = CommandType.StoredProcedure;

                cmd.Parameters.AddWithValue("@PatientId", pat.PatientId);
                cmd.Parameters.AddWithValue("@PhoneNumber", pat.PhoneNumber);
                cmd.Parameters.AddWithValue("@Address", pat.Address);
                cmd.Parameters.AddWithValue("@Email", pat.Email);


                connection.Open();
                cmd.ExecuteNonQuery();
            }
        }

        //public List<string> GetDepartments()
        //{
        //    var departments = new List<string>();

        //    using (SqlConnection connection = new SqlConnection(connectionString))
        //    {
        //        SqlCommand cmd = new SqlCommand("sp_GetDepartments", connection);
        //        cmd.CommandType = CommandType.StoredProcedure;

        //        connection.Open(); // Open the connection before executing the command

        //        using (SqlDataReader reader = cmd.ExecuteReader())
        //        {
        //            while (reader.Read())
        //            {
        //                departments.Add(reader["DepartmentName"].ToString());
        //            }
        //        }
        //    }

        //    return departments;
        //}

        //public IEnumerable<Doctor> GetDoctors()
        //{
        //    List<Doctor> doctors = new List<Doctor>();
        //    using (SqlConnection connection = new SqlConnection(connectionString))
        //    {
        //        SqlCommand cmd = new SqlCommand("sp_GetDoctorsByDepartmentNameR", connection);
        //        connection.Open();
        //        SqlDataReader dr = cmd.ExecuteReader();
        //        while (dr.Read())
        //        {
        //            Doctor doctor = new Doctor
        //            {
        //                DoctorId = Convert.ToInt32(dr["DoctorId"]),
        //                DoctorCode = dr["DoctorCode"].ToString(),
        //                ConsultationFee = Convert.ToDecimal(dr["ConsultationFee"]),
        //                SpecializationId = Convert.ToInt32(dr["SpecializationId"])
        //            };
        //            doctors.Add(doctor);
        //        }
        //    }
        //    return doctors;
        //}

        public IEnumerable<Doctor> GetDoctorsByDepartment(int departmentId)
        { 
            var doctors=new List<Doctor>();

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection .Open();
                using (SqlCommand  cmd = new SqlCommand("sp_GetDoctorsByDepartmentNameR", connection ))
                {
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd .Parameters .AddWithValue ("@DepartmentId",departmentId );
                    
                    using(SqlDataReader reader = cmd.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            doctors.Add(new Doctor
                            {
                                DoctorId = Convert.ToInt32(reader["DoctorId"]),
                                DoctorName = reader["DoctorName"].ToString()
                            });
                        }
                        return doctors;
                    }
                }

            }
        }
        public IEnumerable<Department> GetDepartments()
        {
            using (var connection = new SqlConnection(connectionString))
            {
                connection.Open();

                using (var command = new SqlCommand("sp_GetDepartmentsR", connection))
                {
                    using (var reader = command.ExecuteReader())
                    {
                        var departments = new List<Department>();
                        while (reader.Read())
                        {
                            departments.Add(new Department()
                            {
                                DepartmentId = reader.GetInt32(0),
                                DepartmentName = reader.GetString(1)
                            });
                        }

                        return departments;
                    }
                }
            }
        }


        public void AddAppointments(AppointmentModel app)
        {
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                SqlCommand cmd = new SqlCommand("sp_AddAppointmentR", connection); // Assuming procedure is named Sp_InsertPatient
                cmd.CommandType = CommandType.StoredProcedure;

                // Updated parameters to match the table structure
                cmd.Parameters.AddWithValue("@DepartmentName", app.DepartmentName);
                cmd.Parameters.AddWithValue("@DoctorName", app.DoctorName);
                cmd.Parameters.AddWithValue("@AppointmentDate", app.AppointmentDate);
               
               
                connection.Open();
                cmd.ExecuteNonQuery();
            }
        }

        public IEnumerable<AppointmentModel> GetAppointmentsByPatientId(int patientId)
        {
            throw new NotImplementedException();
        }

      
    }

}

