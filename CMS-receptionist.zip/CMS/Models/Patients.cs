﻿
using System.ComponentModel.DataAnnotations;

namespace CMS.Models
    {
        public class Patients
        {
        [Key]
            public int PatientId { get; set; }

            [Required(ErrorMessage = "Patient name is required.")]
            public string PatientName { get; set; }

            [Required(ErrorMessage = "Date of Birth is required.")]
            [CustomValidation(typeof(Patients), nameof(ValidateDOB))]
            public DateTime DOB { get; set; }

            [Required(ErrorMessage = "Gender is required.")]
            public string Gender { get; set; }

            [Required(ErrorMessage = "Blood group is required.")]
            [RegularExpression("^(A|B|AB|O)[+-]$", ErrorMessage = "Invalid blood group format. Example: A+, O-")]
            public string BloodGroup { get; set; }

            [Required(ErrorMessage = "Phone number is required.")]
            [RegularExpression(@"^\+?[0-9]{10,15}$", ErrorMessage = "Invalid phone number format.")]
            public string PhoneNumber { get; set; }

            [Required(ErrorMessage = "Address is required.")]
            public string Address { get; set; }

            [EmailAddress(ErrorMessage = "Invalid email address.")]
            public string? Email { get; set; } // Nullable Email

        public DateTime DateOfRegistration { get; set; }  // Nullable DateTime

        // Static validation method for DOB
        public static ValidationResult ValidateDOB(DateTime dob, ValidationContext context)
            {
                if (dob > DateTime.Now)
                {
                    return new ValidationResult("Date of Birth cannot be a future date.");
                }
                return ValidationResult.Success!;
            }
        }
    }



