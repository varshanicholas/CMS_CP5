﻿using System.ComponentModel.DataAnnotations;

namespace CMS.Models
{
    public class AppointmentModel
    {
       
        public string DepartmentName { get; set; }
        public string  DoctorName { get; set; }
       
        public DateTime AppointmentDate { get; set; }
        

    }
}
