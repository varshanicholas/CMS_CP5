﻿using CMS.Models;
using CMS.Repository;

using Microsoft.AspNetCore.Mvc;

namespace CMS.Controllers
{
    public class ReceptionistController : Controller
    {
        IReceptionistRepository receptionistRepository = null;
        private object _receptionistRepository;

        public ReceptionistController(IReceptionistRepository _receptionistRepository)
        {
            receptionistRepository = _receptionistRepository;
        }
        public IActionResult Index(string search)
        {
            // Fetch patients from the repository with search applied
            List<Patients> PatList = new List<Patients>();

            if (string.IsNullOrEmpty(search))
            {
                PatList = receptionistRepository.GetPatients().ToList(); // No search applied
                ViewData["IsSearchResult"] = false;  // No search result
            }
            else
            {
                // Filter by name or phone (adjust based on your data structure)
                PatList = receptionistRepository.GetPatients()
                                                .Where(p => p.PatientName.Contains(search) || p.PhoneNumber.Contains(search))
                                                .ToList();
                ViewData["IsSearchResult"] = true;  // Search result present
            }

            ViewData["Query"] = search;  // Store query in ViewData to retain it for the search input
            return View(PatList);
        }



        public IActionResult Create()
        {
            return View();
        }
        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Create([Bind] Patients objPat)
        {
            if (ModelState.IsValid)
            {
                receptionistRepository.AddPatients(objPat);

            }
            return RedirectToAction("Index");
        }

        //Get the details of an employee
        public IActionResult Details(int? Id)
        {
            if (Id == null)
            {
                return NotFound();
            }

            Patients pat = receptionistRepository.GetPatientById(Id);
            if (pat == null)
            {
                return NotFound();
            }

            return View(pat);
        }


        public IActionResult Edit(int? Id)
        {
            if (Id == null)
            {
                return NotFound();
            }

            Patients patient = receptionistRepository.GetPatientById(Id);
            if (patient == null)
            {
                return NotFound();
            }

            return View(patient);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Edit([Bind] Patients objpat)
        {
            if (ModelState.IsValid)
            {
                receptionistRepository.UpdatePatients(objpat);
            }
            return RedirectToAction("Index");
        }

       

    }
}
